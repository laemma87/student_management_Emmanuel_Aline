<?php
require_once 'Student.php';

$student = new Student();

if(isset($_POST['add'])) {
    $student->firstname = $_POST['firstname'];
    $student->lastname = $_POST['lastname'];
    $student->email = $_POST['email'];
    $student->phone = $_POST['phone'];
    $student->create();
    header("Location:index.php");
}

if(isset($_POST['update'])) {
    $student->id = $_POST['id'];
    $student->firstname = $_POST['firstname'];
    $student->lastname = $_POST['lastname'];
    $student->email = $_POST['email'];
    $student->phone = $_POST['phone'];
    $student->update();
    header("Location:index.php");
}

if(isset($_GET['delete'])) {
    $student->id = $_GET['delete'];
    $student->delete();
    header("Location:index.php");
}
?>
