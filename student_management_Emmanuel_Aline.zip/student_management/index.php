<?php
require_once 'Student.php';
$studentModel = new Student();

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_POST['add'])){
        $studentModel->firstname = $_POST['firstname'];
        $studentModel->lastname = $_POST['lastname'];
        $studentModel->email = $_POST['email'];
        $studentModel->phone = $_POST['phone'];
        $studentModel->create();
    }
    if(isset($_POST['update'])){
        $studentModel->id = $_POST['id'];
        $studentModel->firstname = $_POST['firstname'];
        $studentModel->lastname = $_POST['lastname'];
        $studentModel->email = $_POST['email'];
        $studentModel->phone = $_POST['phone'];
        $studentModel->update();
    }
    if(isset($_POST['clear'])){
        $_POST = [];
    }
}

if(isset($_GET['delete'])){
    $studentModel->id = $_GET['delete'];
    $studentModel->delete();
}

$students = $studentModel->readAll();

$editStudent = null;
if(isset($_GET['edit'])){
    foreach($students as $s){
        if($s['id'] == $_GET['edit']){
            $editStudent = (object)$s;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Student Management System</h2>

    <form method="POST">
        <input type="hidden" name="id" value="<?= $editStudent ? $editStudent->id : ''; ?>"><br><br>
        <label>First Name:</label>
        <input type="text" name="firstname" value="<?= $editStudent ? $editStudent->firstname : ''; ?>" required><br><br>
        <label>Last Name:</label>
        <input type="text" name="lastname" value="<?= $editStudent ? $editStudent->lastname : ''; ?>" required><br><br><br>

        <label>Email:</label>
        <input type="email" name="email" value="<?= $editStudent ? $editStudent->email : ''; ?>" required><br><br>
        <label>Phone:</label>
        <input type="text" name="phone" value="<?= $editStudent ? $editStudent->phone : ''; ?>" required><br>

        <button type="submit" name="add">Add</button>
        <button type="submit" name="update">Update</button>
        <button type="submit" name="clear">Clear</button>
        <button type="submit" name="view">View/Load</button>
    </form>

    <!-- Student Table -->
    <table border="1" cellpadding="10">
        <tr>
            <th>ID</th><th>First Name</th><th>Last Name</th><th>Email</th><th>Phone</th><th>Actions</th>
        </tr>
        <?php foreach($students as $s): ?>
        <tr>
            <td><?= $s['id']; ?></td>
            <td><?= $s['firstname']; ?></td>
            <td><?= $s['lastname']; ?></td>
            <td><?= $s['email']; ?></td>
            <td><?= $s['phone']; ?></td>
            <td>
                <a href="?edit=<?= $s['id']; ?>">Edit</a> | 
                <a href="?delete=<?= $s['id']; ?>" onclick="return confirm('Delete this student?')">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
