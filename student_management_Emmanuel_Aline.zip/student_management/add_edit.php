<?php
require_once 'Student.php';
$student = new Student();
$editing = false;

if(isset($_GET['id'])) {
    $editing = true;
    $id = $_GET['id'];
    $allStudents = $student->readAll();
    foreach($allStudents as $s) {
        if($s['id'] == $id) {
            $student = (object)$s;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= $editing ? "Edit Student" : "Add Student"; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2><?= $editing ? "Edit Student" : "Add New Student"; ?></h2>
    <form method="POST" action="StudentController.php">
        <?php if($editing): ?>
            <input type="hidden" name="id" value="<?= $student->id; ?>">
        <?php endif; ?>
        <label>First Name:</label><input type="text" name="firstname" value="<?= $editing ? $student->firstname : ""; ?>" required><br>
        <label>Last Name:</label><input type="text" name="lastname" value="<?= $editing ? $student->lastname : ""; ?>" required><br>
        <label>Email:</label><input type="email" name="email" value="<?= $editing ? $student->email : ""; ?>" required><br>
        <label>Phone:</label><input type="text" name="phone" value="<?= $editing ? $student->phone : ""; ?>" required><br>
        <button type="submit" name="<?= $editing ? "update" : "add"; ?>"><?= $editing ? "Update" : "Add"; ?></button>
    </form>
    <a href="index.php">Back</a>
</body>
</html>
