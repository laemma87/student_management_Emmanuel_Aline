<?php
require_once 'connection.php';

class Student {
    private $conn;
    private $table = "students";

    public $id;
    public $firstname;
    public $lastname;
    public $email;
    public $phone;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Create
    public function create() {
        $sql = "INSERT INTO {$this->table} (firstname, lastname, email, phone) 
                VALUES (:firstname, :lastname, :email, :phone)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':firstname', $this->firstname);
        $stmt->bindParam(':lastname', $this->lastname);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':phone', $this->phone);
        return $stmt->execute();
    }

    public function readAll() {
        $sql = "SELECT * FROM {$this->table}";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function update() {
        $sql = "UPDATE {$this->table} SET firstname=:firstname, lastname=:lastname, email=:email, phone=:phone WHERE id=:id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':firstname', $this->firstname);
        $stmt->bindParam(':lastname', $this->lastname);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':id', $this->id);
        return $stmt->execute();
    }

    public function delete() {
        $sql = "DELETE FROM {$this->table} WHERE id=:id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':id', $this->id);
        return $stmt->execute();
    }
}
?>
